package model.Bean;

import java.sql.SQLException;
import java.util.Collection;

public interface ProductModel {
	
	public void doSave(ProductBean p) throws SQLException;
	
	public boolean doDelete(String codice_prodotto) throws SQLException;
	
	public ProductBean doRetrieveByKey(String codice_prodotto) throws SQLException; 
	
	public Collection<ProductBean> doRetrieveAll(String order) throws SQLException;

	Collection<ProductBean> doRetrieveAll(String order, String group) throws SQLException;
	
	public Collection<ProductBean> doRetrieveByCategory(String macroCategoria) throws SQLException;
	
}
