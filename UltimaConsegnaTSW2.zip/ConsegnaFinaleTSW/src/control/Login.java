package control;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.Bean.UserBean;
import model.DAO.UserDAO_DM;

@WebServlet("/Login")
public class Login extends HttpServlet {

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		String redirectedpage = null;
		try {
			UserDAO_DM ud = new UserDAO_DM();
			UserBean ub = new UserBean();
			ub = ud.doRetrieveByKey(username);
			if(request.getSession().getAttribute("adminredirect") != null)
			{
				request.getSession().removeAttribute("adminredirect");
			}
			checkLogin(username, password, ub);
			request.getSession().setAttribute("adminRoles", Boolean.valueOf(true));
			request.getSession().setAttribute("failedLogin", false);
			/*Nuova versione, per l'ordine
			request.getSession().setAttribute("firstname", ub.getNome());
			request.getSession().setAttribute("lastname", ub.getCognome());
			*/
			if(request.getSession().getAttribute("utentesessione") != null)
			{
				System.out.println("Debug: pf in sessione all'inizio del login = " + ((UserBean) request.getSession().getAttribute("utentesessione")).getN_punti_fedelta());
			}
			else
			{
				request.getSession().setAttribute("utentesessione", ub);
			}
			if(request.getSession().getAttribute("utentesessione") != null)
			{
				System.out.println("Debug: pf in sessione in login dopo avere reimpostato il bean = " + ((UserBean) request.getSession().getAttribute("utentesessione")).getN_punti_fedelta());
			}
			if(checkAdmin(ub))
			{
				request.getSession().setAttribute("adminredirect", true);
			}
			if(request.getSession().getAttribute("utentesessione") != null)
			{
				System.out.println("Debug: pf in sessione in login prima di avere impostato il redirect a userlogged = " + ((UserBean) request.getSession().getAttribute("utentesessione")).getN_punti_fedelta());
			}
			redirectedpage = "/userLogged.jsp";
			
		}catch (Exception e) {
			
			redirectedpage = "/LoginPage.jsp";
			request.getSession().setAttribute("failedLogin", Boolean.valueOf(true));
		}
		if(request.getSession().getAttribute("utentesessione") != null)
		{
			System.out.println("Debug: pf in sessione alla fine di login prima del redirect= " + ((UserBean) request.getSession().getAttribute("utentesessione")).getN_punti_fedelta());
		}
		response.sendRedirect(request.getContextPath() + redirectedpage);
	}

	private boolean checkAdmin(UserBean ub) throws Exception
	{
		if(ub.getPassword().equals("ADRex56@") && ub.getEmail().equals("adminaccount@email.dominio"))
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
	private void checkLogin(String username, String password, UserBean ub) throws Exception {
		if (ub.getPassword().equals(password) && ub.getEmail().equals(username)) {
		}
		else {
			throw new Exception("Invalid login");
		}
	}
	
	private static final long serialVersionUID = 1L;

	public Login() {
		super();
	}	

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
		
	}
	

}
